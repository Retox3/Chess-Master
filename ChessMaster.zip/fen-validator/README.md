# fen-validator

Library to validate the Chess [FEN notation](https://en.wikipedia.org/wiki/Forsyth–Edwards_Notation). This library was copied from [jayasurian123](https://github.com/jayasurian123)/[fen-validator](https://github.com/jayasurian123/fen-validator) on April 21, 2023. 

# License

GNU GENERAL PUBLIC LICENSE V3
