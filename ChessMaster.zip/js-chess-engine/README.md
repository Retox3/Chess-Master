# JS-CHESS-ENGINE

Library to validate the Chess [FEN notation](https://en.wikipedia.org/wiki/Forsyth–Edwards_Notation). This library was copied from [josefjadrny](https://github.com/josefjadrny)/[js-chess-engine](https://github.com/josefjadrny/js-chess-engine) on April 25, 2023. 

# License

MIT License
